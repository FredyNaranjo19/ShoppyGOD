
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="../items/plantillas/demos/persuit/js/jquery-3.2.1.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="../items/plantillas/demos/persuit/js/popper.min.js"></script>
<script src="../items/plantillas/demos/persuit/js/bootstrap.min.js"></script>
<!-- Rev slider js -->
<script src="../items/plantillas/demos/persuit/vendors/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<!-- Extra plugin css -->
<script src="../items/plantillas/demos/persuit/vendors/counterup/jquery.waypoints.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/counterup/jquery.counterup.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/bootstrap-selector/js/bootstrap-select.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/image-dropdown/jquery.dd.min.js"></script>
<script src="../items/plantillas/demos/persuit/js/smoothscroll.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/isotope/imagesloaded.pkgd.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/isotope/isotope.pkgd.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/magnify-popup/jquery.magnific-popup.min.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/vertical-slider/js/jQuery.verticalCarousel.js"></script>
<script src="../items/plantillas/demos/persuit/vendors/jquery-ui/jquery-ui.js"></script>
<script src="../items/plantillas/demos/persuit/js/theme.js"></script>

<script src="../items/sweetalert2/sweetalert2.all.js"></script>
 

<script src="https://www.gstatic.com/firebasejs/7.23.0/firebase-app.js"></script>

<script src="https://www.gstatic.com/firebasejs/7.23.0/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.23.0/firebase-firestore.js"></script>

<script src="https://www.gstatic.com/firebasejs/7.23.0/firebase-storage.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.23.0/firebase-database.js"></script>

<script src="../items/js/firestore-config.js"></script>
<script src="../items/js/configuracion-dimensionar-Imagen.js"></script>

<!-- ARCHIVOS JS PERSONALIZADOS -->
<script src="../items/plantillas/persuit/js/header.js?v=<?php echo $versionSistema ?>"></script>
<script src="../items/plantillas/persuit/js/historial.js?v=<?php echo $versionSistema ?>"></script>
<script src="../items/plantillas/persuit/js/inicio.js?v=<?php echo $versionSistema ?>"></script>
<script src="../items/plantillas/persuit/js/login.js?v=<?php echo $versionSistema ?>"></script>
<script src="../items/plantillas/persuit/js/producto.js?v=<?php echo $versionSistema ?>"></script>
<script src="../items/plantillas/persuit/js/detalle.js?v=<?php echo $versionSistema ?>"></script>
<script src="../items/plantillas/persuit/js/link.js?v=<?php echo $versionSistema ?>"></script>
<script src="../items/plantillas/persuit/js/shopping-cart.js?v=<?php echo $versionSistema ?>"></script>
<script src="../items/plantillas/persuit/js/proccess.js?v=<?php echo $versionSistema ?>"></script>