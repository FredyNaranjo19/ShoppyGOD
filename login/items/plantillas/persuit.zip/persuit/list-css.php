<!-- Icon css link -->
<link href="../items/plantillas/demos/persuit/css/font-awesome.min.css" rel="stylesheet">
<link href="../items/plantillas/demos/persuit/vendors/line-icon/css/simple-line-icons.css" rel="stylesheet">
<link href="../items/plantillas/demos/persuit/vendors/elegant-icon/style.css" rel="stylesheet">

<!-- Bootstrap -->
<link href="../items/plantillas/demos/persuit/css/bootstrap.min.css" rel="stylesheet">

<!-- Rev slider css -->
<link href="../items/plantillas/demos/persuit/vendors/revolution/css/settings.css" rel="stylesheet">
<link href="../items/plantillas/demos/persuit/vendors/revolution/css/layers.css" rel="stylesheet">
<link href="../items/plantillas/demos/persuit/vendors/revolution/css/navigation.css" rel="stylesheet">

<!-- Extra plugin css -->
<link href="../items/plantillas/demos/persuit/vendors/owl-carousel/owl.carousel.min.css" rel="stylesheet">
<link href="../items/plantillas/demos/persuit/vendors/bootstrap-selector/css/bootstrap-select.min.css" rel="stylesheet">
<link href="../items/plantillas/demos/persuit/vendors/vertical-slider/css/jQuery.verticalCarousel.css" rel="stylesheet">

<!-- LINKS CSS -->   
<link href="../items/plantillas/persuit/items/css/style.css" rel="stylesheet">
<link href="../items/plantillas/persuit/items/css/responsive.css" rel="stylesheet">

<!-- LINKS CSS PERSONALES -->
<link href="../items/plantillas/demos/persuit/css/productos.css?v=<?php echo $versionSistema ?>" rel="stylesheet">
<link href="../items/plantillas/demos/persuit/css/redes.css?v=<?php echo $versionSistema ?>" rel="stylesheet">
<link href="../items/plantillas/demos/persuit/css/inicio.css?v=<?php echo $versionSistema ?>" rel="stylesheet">



<?php include 'modulos/fix/configStyle.php'; ?>